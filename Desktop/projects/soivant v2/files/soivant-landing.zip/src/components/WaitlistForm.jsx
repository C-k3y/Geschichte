import { useState } from 'react';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/**
 * WaitlistForm
 * ---------------------------------------------------------------------------
 * Self-contained email capture with client-side validation and status
 * states (idle / loading / success / error). `onSubmit` is injected so this
 * component stays UI-only: today it resolves against a mocked delay, and
 * swapping in a real API call (POST /api/waitlist, a Mailchimp/Klaviyo
 * request, etc.) means changing the prop passed in from a parent — nothing
 * in this file needs to change.
 *
 * @param {(email: string) => Promise<void>} onSubmit
 * @param {string} ctaLabel
 */
export default function WaitlistForm({ onSubmit, ctaLabel = 'Notify me' }) {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState('idle'); // idle | loading | success | error
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!EMAIL_RE.test(email)) {
      setError('Enter a valid email address.');
      setStatus('error');
      return;
    }

    setStatus('loading');
    setError('');

    try {
      await onSubmit(email);
      setStatus('success');
    } catch (err) {
      setError(err?.message || 'Something went wrong. Try again.');
      setStatus('error');
    }
  };

  if (status === 'success') {
    return (
      <p className="font-display italic text-champagne-bright text-lg" role="status">
        You&rsquo;re on the list — check your inbox soon.
      </p>
    );
  }

  return (
    <form onSubmit={handleSubmit} noValidate className="w-full max-w-md">
      <div className="flex flex-col sm:flex-row gap-3">
        <label htmlFor="waitlist-email" className="sr-only">
          Email address
        </label>
        <input
          id="waitlist-email"
          type="email"
          inputMode="email"
          autoComplete="email"
          placeholder="you@email.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          aria-invalid={status === 'error'}
          aria-describedby={status === 'error' ? 'waitlist-error' : undefined}
          className="flex-1 bg-transparent border border-white/15 focus:border-champagne px-4 py-3
                     text-sm text-bone placeholder:text-ash outline-none transition-colors"
        />
        <button
          type="submit"
          disabled={status === 'loading'}
          className="whitespace-nowrap bg-champagne text-ink text-xs tracking-widest2 uppercase
                     font-medium px-6 py-3 hover:bg-champagne-bright transition-colors
                     disabled:opacity-60 disabled:cursor-wait"
        >
          {status === 'loading' ? 'Joining…' : ctaLabel}
        </button>
      </div>
      {status === 'error' && (
        <p id="waitlist-error" className="mt-2 text-xs text-red-300/80">
          {error}
        </p>
      )}
    </form>
  );
}
