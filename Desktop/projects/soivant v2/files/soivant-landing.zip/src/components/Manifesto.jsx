import { pillars } from '../data/content.js';
import SeamDivider from './SeamDivider.jsx';

export default function Manifesto() {
  return (
    <section id="manifesto" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-6xl px-6 md:px-10">
        <div className="text-center max-w-2xl mx-auto">
          <p className="text-xs tracking-widest3 uppercase text-champagne">This is my story</p>
          <h2 className="mt-4 font-display text-4xl md:text-5xl text-bone">
            Wear your story.
          </h2>
        </div>

        <div className="mt-16 grid gap-6 md:grid-cols-3">
          {pillars.map((pillar) => (
            <article key={pillar.title} className="stitch-card p-8 flex flex-col gap-4">
              <span className="font-display italic text-champagne-muted text-sm">{pillar.mark}</span>
              <h3 className="font-display text-2xl text-bone">{pillar.title}</h3>
              <p className="text-sm leading-relaxed text-ash">{pillar.body}</p>
            </article>
          ))}
        </div>
      </div>

      <div className="mt-24 md:mt-32 px-6 md:px-10">
        <SeamDivider />
      </div>
    </section>
  );
}
