import { useEffect, useState } from 'react';
import { brand, navLinks } from '../data/content.js';

/**
 * Navbar
 * ---------------------------------------------------------------------------
 * Minimal, letter-spaced nav that darkens/solidifies on scroll so it stays
 * legible over whatever section is behind it. Mobile collapses into a
 * simple full-screen sheet rather than a cramped hamburger dropdown.
 */
export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-40 transition-colors duration-300 ${
        scrolled ? 'bg-ink/90 backdrop-blur-sm border-b border-white/5' : 'bg-transparent'
      }`}
    >
      <nav className="mx-auto max-w-6xl px-6 md:px-10 h-16 md:h-20 flex items-center justify-between">
        <a
          href="#top"
          className="font-display text-lg md:text-xl tracking-widest2 text-bone hover:text-champagne transition-colors"
        >
          {brand.name}
        </a>

        <ul className="hidden md:flex items-center gap-10 text-xs tracking-widest2 uppercase text-ash">
          {navLinks.map((link) => (
            <li key={link.href}>
              <a href={link.href} className="hover:text-champagne transition-colors">
                {link.label}
              </a>
            </li>
          ))}
        </ul>

        <a
          href="#waitlist"
          className="hidden md:inline-block text-xs tracking-widest2 uppercase border border-champagne-muted
                     px-5 py-2.5 text-champagne hover:bg-champagne hover:text-ink transition-colors"
        >
          Notify me
        </a>

        {/* Mobile toggle */}
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
          aria-label="Toggle menu"
          className="md:hidden w-8 h-8 flex flex-col justify-center gap-1.5"
        >
          <span className={`h-px bg-bone transition-transform ${open ? 'translate-y-[3.5px] rotate-45' : ''}`} />
          <span className={`h-px bg-bone transition-opacity ${open ? 'opacity-0' : ''}`} />
          <span className={`h-px bg-bone transition-transform ${open ? '-translate-y-[3.5px] -rotate-45' : ''}`} />
        </button>
      </nav>

      {/* Mobile sheet */}
      {open && (
        <div className="md:hidden bg-ink border-t border-white/5 px-6 py-8 flex flex-col gap-6">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={() => setOpen(false)}
              className="text-sm tracking-widest2 uppercase text-bone hover:text-champagne"
            >
              {link.label}
            </a>
          ))}
          <a
            href="#waitlist"
            onClick={() => setOpen(false)}
            className="text-sm tracking-widest2 uppercase text-champagne border border-champagne-muted px-5 py-3 text-center"
          >
            Notify me
          </a>
        </div>
      )}
    </header>
  );
}
