import { waitlistCopy } from '../data/content.js';
import WaitlistForm from './WaitlistForm.jsx';

async function submitToWaitlist(email) {
  await new Promise((resolve) => setTimeout(resolve, 700));
  // eslint-disable-next-line no-console
  console.info('[waitlist] captured email:', email);
}

export default function WaitlistSection() {
  return (
    <section id="waitlist" className="relative py-24 md:py-32 bg-charcoal">
      <div className="mx-auto max-w-2xl px-6 md:px-10 text-center flex flex-col items-center">
        <p className="text-xs tracking-widest3 uppercase text-champagne">{waitlistCopy.eyebrow}</p>
        <h2 className="mt-4 font-display text-4xl md:text-5xl text-bone">{waitlistCopy.heading}</h2>
        <p className="mt-4 text-sm md:text-base text-ash max-w-md">{waitlistCopy.body}</p>

        <div className="mt-10 flex justify-center">
          <WaitlistForm onSubmit={submitToWaitlist} ctaLabel={waitlistCopy.ctaLabel} />
        </div>
      </div>
    </section>
  );
}
