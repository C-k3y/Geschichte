/**
 * content.js
 * ---------------------------------------------------------------------------
 * Single source of truth for site copy, nav links, product teasers and
 * launch settings. Keeping this separate from the components means the
 * marketing/ops side of the business can update copy, swap the launch date,
 * or add a new pillar/product without touching JSX — and it's the natural
 * seam to later replace with a CMS (Sanity, Contentful) or a fetch() call
 * to a real backend without changing any component internals.
 */

export const brand = {
  name: 'SOIVANT',
  tagline: 'Wear your story.',
  lineName: 'Geschichte',
  lineLabel: 'The Geschichte Line',
  strapline: 'Stories woven. Purpose worn.',
  instagram: '@soivant.co',
  instagramUrl: 'https://instagram.com/soivant.co',
};

// ISO date the countdown targets. Change this one value to move the launch.
export const launchDate = '2026-11-14T09:00:00';

export const navLinks = [
  { label: 'The Line', href: '#manifesto' },
  { label: 'Collection', href: '#collection' },
  { label: 'Waitlist', href: '#waitlist' },
];

// The three-line poster copy — "Every scar. Every lesson. Every victory." —
// expanded into a real manifesto grid. Order carries meaning here: it's a
// chronology (wound → meaning → outcome), so numbering the pillars is
// justified rather than decorative.
export const pillars = [
  {
    mark: 'I',
    title: 'Every scar.',
    body: 'Every piece starts from something lived-through, not a mood board. We stitch the mark first, then build the garment around it.',
  },
  {
    mark: 'II',
    title: 'Every lesson.',
    body: 'Construction details are earned, not decorative — heavyweight cotton, reinforced seams, a fit that holds up to the story it carries.',
  },
  {
    mark: 'III',
    title: 'Every victory.',
    body: 'The Geschichte monogram is worn quietly, on the chest and on the patch — proof kept close, not shouted.',
  },
];

// Product teaser cards for the "Collection" section. `locked: true` renders
// the pre-launch treatment; flip it to false (and add real imagery /
// pricing) once the drop goes live — no structural changes needed.
export const products = [
  {
    id: 'hoodie-geschichte',
    name: 'Geschichte Hoodie',
    detail: 'Heavyweight fleece · embroidered monogram · raw hem drawcord',
    swatch: 'from-[#211d16] via-[#171410] to-[#0b0a08]',
    locked: true,
  },
  {
    id: 'sweatpant-geschichte',
    name: 'Geschichte Sweatpant',
    detail: 'Tapered fit · woven leather patch · deep side pockets',
    swatch: 'from-[#1c1913] via-[#151209] to-[#0b0a08]',
    locked: true,
  },
];

export const waitlistCopy = {
  eyebrow: 'Launching soon',
  heading: 'Be first through the door.',
  body: 'Join the list and get early access before the Geschichte line opens to the public — plus one email, the day it drops.',
  ctaLabel: 'Notify me',
  successHeading: "You're on the list.",
  successBody: "We'll email you the moment the Geschichte line is live.",
};
