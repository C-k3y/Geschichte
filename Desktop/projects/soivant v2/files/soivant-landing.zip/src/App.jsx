import Navbar from './components/Navbar.jsx';
import Hero from './components/Hero.jsx';
import Manifesto from './components/Manifesto.jsx';
import CollectionPreview from './components/CollectionPreview.jsx';
import WaitlistSection from './components/WaitlistSection.jsx';
import Footer from './components/Footer.jsx';
import GrainOverlay from './components/GrainOverlay.jsx';

/**
 * App
 * ---------------------------------------------------------------------------
 * Composition root. Sections are self-contained and read their copy from
 * src/data/content.js, so reordering, removing, or adding a new section
 * (e.g. a lookbook, a press strip) is a one-line change here plus a new
 * component file — nothing else in the tree needs to know about it.
 */
export default function App() {
  return (
    <div className="relative min-h-screen bg-ink text-bone overflow-x-hidden">
      <GrainOverlay />
      <div className="relative z-10">
        <Navbar />
        <main>
          <Hero />
          <Manifesto />
          <CollectionPreview />
          <WaitlistSection />
        </main>
        <Footer />
      </div>
    </div>
  );
}
